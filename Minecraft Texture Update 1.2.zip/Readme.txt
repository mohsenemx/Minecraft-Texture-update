Minecraft 1.14 Texture Update Pack by MohsenEMX

Auther: MohsenEMX
Pack Version: 1.2
Build Date: 7/26/2021 
Last Update Date: 7/29/2021

You are free to use this pack in your videos,modpacks are even worlds.
If you can, put direct download link of this pack.





**Notice: Taetures are taken from offical minecraft. **


Please Note: This is a Heavy Texture Pack Becouse of It Changes Everything!

Some blocks may still stay on they old texture: I'll fix it on next updates.

Latest Change Log:
1.2:
- Lowered Volume of This Pack
- Added 1.13 Support
1.1:
- Fixed Items Texture Bug
- Optimized for Better Performance
1:
- Pack is Created


Thanks for downloading!